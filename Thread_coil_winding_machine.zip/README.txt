                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3326307
Thread coil winding machine by electricdiylab is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

$2 for 10 PCBs & $6 for stencil: https://jlcpcb.com
You can get up to 30% off on pcbs and 20 % off on Stencils

Hello friends in this video I have made a thread coil winding machine, using arduino and 3D printed parts, for GUI I have used 0.96 OLED display and for user input I have used a rotary encoder knob. a Photoelectric Speed Sensor is used the measure the length of thread. 
Machine have two mode of operation 1st is manual mode in which thread start to wind on coil until stop is not pressed in in 2nd mode Auto mode machine will wind the thread as per the user predefined length.

Circuit & Code 
https://www.mediafire.com/file/gssy6slscrrla8l/COIL_WINDING_MACHINE.rar/file

Material Required 
1) Arduino UNO :-  https://amzn.to/2R0Cwy8
2) 0.96" OLED display :-  https://amzn.to/2R0vJnX
3) Encoder knob :- https://amzn.to/2Svt7LA
4) DC Motor :- https://amzn.to/2GOGbdR
5) Servo motor :- https://amzn.to/2RrxTwp
6) L293D IC :-  https://amzn.to/2Qfuo7C
7) Photoelectric Speed Sensor :-  https://amzn.to/2BQ9hDF

https://youtu.be/tsxu_KMYnTs